// fonte.js

// Aplica o tamanho salvo, se existir
/*
document.addEventListener("DOMContentLoaded", () => {
  const tamanhoFonte = localStorage.getItem("tamanhoFonte");
  if (tamanhoFonte) {
    document.documentElement.style.fontSize = tamanhoFonte;
    console.log("teste")
  }
});

// Chamada pelo botão na página principal
function definirFonteGrande() {
  const novoTamanho = "20px"; // ou outro valor fixo
  localStorage.setItem("tamanhoFonte", novoTamanho);
  document.documentElement.style.fontSize = novoTamanho;
  console.log("teste1")
}

function redefinirFonte() {
  localStorage.removeItem("tamanhoFonte");
  document.documentElement.style.fontSize = "16px"; // valor padrão
}

function aumentarFonte() {
            const tamanhoAtual = parseInt(localStorage.getItem('tamanhoFonte')) || 16;
            const novoTamanho = tamanhoAtual + 2; // Aumenta 2px a cada clique
            document.body.style.fontSize = novoTamanho + 'px';
            localStorage.setItem('tamanhoFonte', novoTamanho);
        }

window.onload = function() {
            const tamanhoSalvo = localStorage.getItem('tamanhoFonte');
            if (tamanhoSalvo) {
                document.body.style.fontSize = tamanhoSalvo + 'px';
            }
        };*/