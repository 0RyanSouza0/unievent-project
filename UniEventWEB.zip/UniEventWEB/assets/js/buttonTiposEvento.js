const buttons = document.querySelectorAll('.event-button');

buttons.forEach(button => {
    button.addEventListener('click', () => {
        // Alterna apenas o botão clicado
        button.classList.toggle('selected');
    });
});