function escolherArquivo(){
    // vamos obter uma referência ao elemento file
    var arquivo = document.getElementById("upload");
    // vamos disparar seu evento onclick()
    arquivo.click();  }